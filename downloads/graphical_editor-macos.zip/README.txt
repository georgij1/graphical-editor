Placeholder for graphical editor client.
Replace with a real build artifact.
