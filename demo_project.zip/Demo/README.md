# Demo

JavaFX application built with the FXML Editor.

## Layout

```text
src/main/java       Java sources (launcher and scene controllers)
src/main/resources  FXML scenes
```

## Requirements

- JDK 21 or newer
- JavaFX 21.0.2
- Maven 3.8+

## Run

```bash
mvn javafx:run
```
