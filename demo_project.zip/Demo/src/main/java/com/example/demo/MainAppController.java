package com.example.demo;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class MainAppController implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Wire up UI controls here.
    }
}
